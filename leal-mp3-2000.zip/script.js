const tracks=[
["WICKED GAME","Chris Isaak"],["HERO","Enrique Iglesias"],["É O AMOR","Zezé Di Camargo & Luciano"],
["WONDERFUL TONIGHT","Eric Clapton"],["A-PUNK","Vampire Weekend"],["LEAVE THE DOOR OPEN","Silk Sonic"],
["HOTEL CALIFORNIA","Eagles"],["NAQUELA MESA","Nelson Gonçalves"],["GOSTAVA TANTO DE VOCÊ","Tim Maia"],
["SWEET CHILD O' MINE","Guns N' Roses"],["AMOR DE VIOLEIRO","Eduardo Costa"],["BLUE HOTEL","Chris Isaak"],
["ESCAPE","Enrique Iglesias"],["DOIS CORAÇÕES E UMA HISTÓRIA","Zezé Di Camargo & Luciano"],
["TEARS IN HEAVEN","Eric Clapton"],["OXFORD COMMA","Vampire Weekend"],["SMOKIN OUT THE WINDOW","Silk Sonic"],
["TAKE IT EASY","Eagles"],["A VOLTA DO BOÊMIO","Nelson Gonçalves"],["AZUL DA COR DO MAR","Tim Maia"],
["NOVEMBER RAIN","Guns N' Roses"],["ME APAIXONEI","Eduardo Costa"]];
let current=0,playing=false;
const table=document.getElementById("songs");
tracks.forEach((t,i)=>table.innerHTML+=`<tr><td class="num">${String(i+1).padStart(2,"0")}</td><td><span class="song">${t[0]}</span><br><span class="artist">${t[1]}</span></td><td><button class="playbtn" onclick="selectTrack(${i})">PLAY</button></td></tr>`);
function selectTrack(i){current=i;document.getElementById("song").textContent=tracks[i][0];document.getElementById("artist").textContent=tracks[i][1]}
function next(){selectTrack((current+1)%tracks.length)}
function prev(){selectTrack((current-1+tracks.length)%tracks.length)}
function toggle(){playing=!playing;document.getElementById("play").textContent=playing?"PAUSE":"PLAY"}